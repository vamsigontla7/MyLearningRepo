1. Download the zip package
2. Extract the folder to C:\Python27\ and it should look as "C:\Python27\exercise\movie_trailer" 
3. Open MovieTrailerFinalSubmission.py and Run in module.
4. This should open my favourite movie trailers page  